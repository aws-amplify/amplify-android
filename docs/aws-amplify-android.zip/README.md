## AWS SDK for Android (Amplify)

AWS SDK for Android (Amplify)

## License

This library is licensed under the Apache 2.0 License. 
