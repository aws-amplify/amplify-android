package com.amazonaws.amplify.demo;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;
import android.widget.Toast;

import com.amazonaws.amplify.auth.Auth;
import com.amazonaws.amplify.auth.async.Callback;
import com.amazonaws.amplify.auth.google.GoogleSignInDetails;
import com.amazonaws.amplify.auth.google.GoogleSignInProviderBuilder;
import com.amazonaws.amplify.auth.google.GoogleSignInResult;
import com.amazonaws.regions.Regions;
import com.google.android.gms.common.Scopes;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;

import static org.junit.Assert.assertEquals;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class GoogleInstrumentedTest {
    private static final String TAG = GoogleInstrumentedTest.class.getSimpleName();

    @Rule
    public ActivityTestRule<MainActivity> rule  = new ActivityTestRule<>(MainActivity.class);

    @Test
    public void useAppContext() throws InterruptedException {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();

        final MainActivity mainActivity = rule.getActivity();
        final CountDownLatch lock = new CountDownLatch(1);

        GoogleSignInDetails details = GoogleSignInDetails.builder().activity(mainActivity).build();
        Auth auth = Auth.builder()
                .context(appContext)
                .cognitoIdentityPool("poolId", Regions.DEFAULT_REGION, false)
                .provider(new GoogleSignInProviderBuilder().scopes(Scopes.EMAIL, Scopes.PROFILE))
                .build();
        auth.signIn(details, new Callback<GoogleSignInResult>() {
            @Override
            public void onResult(GoogleSignInResult result) {
                Log.e(TAG, "Account display name" + result.getAccount().getDisplayName());
                lock.countDown();
            }

            @Override
            public void onError(Exception e) {
                Log.e(TAG, "Google login onError called.", e);
                lock.countDown();
            }
        });

        mainActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(mainActivity, "Waiting for callback", 1).show();
            }
        });

        lock.await();

        assertEquals("com.amazonaws.amplify.demo", appContext.getPackageName());
    }
}
