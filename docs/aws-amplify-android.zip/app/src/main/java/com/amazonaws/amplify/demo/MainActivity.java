package com.amazonaws.amplify.demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.amazonaws.amplify.auth.Auth;
import com.amazonaws.amplify.auth.async.Callback;
import com.amazonaws.amplify.auth.google.GoogleSignInDetails;
import com.amazonaws.amplify.auth.google.GoogleSignInProvider;
import com.amazonaws.amplify.auth.google.GoogleSignInProviderBuilder;
import com.amazonaws.amplify.auth.google.GoogleSignInResult;
import com.amazonaws.amplify.auth.userpool.UserpoolSignInDetails;
import com.amazonaws.amplify.auth.userpool.UserpoolSignInProvider;
import com.amazonaws.amplify.auth.userpool.UserpoolSignInProviderBuilder;
import com.amazonaws.amplify.auth.userpool.UserpoolSignInResult;
import com.amazonaws.regions.Regions;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();
    public GoogleSignInProvider gsp;
    private static Auth auth;

    public static Auth getAuth() {
        return auth;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String identityPoolID = "poolId";

        // Just login
        //        String userPoolID = "poolId";
        //        String userPoolClientID = "clientId";
        //        String userPoolClientSecret = "clientSecret";

        // Change password
        String userPoolID = "poolId";
        String userPoolClientID = "clientId";
        String userPoolClientSecret = "clientSecret";

        auth = Auth.builder()
                .context(this)
                .cognitoIdentityPool(identityPoolID, Regions.US_WEST_2, false)
//                .caching(false)
                .provider(new UserpoolSignInProviderBuilder(this, Regions.US_WEST_2, userPoolID, userPoolClientID, userPoolClientSecret))
                .provider(new GoogleSignInProviderBuilder().clientID("googleClientId"))
                .build();
        loginGoogle(null);
    }

    public void loginUserPool(final View view) {
        startActivity(new Intent(this, UserpoolSignInActivity.class));
    }

    public static void handleUserpoolSignInResult(final UserpoolSignInResult result, final Activity callingActivity) {
        switch (result.getSignInState()) {
            case SMS_MFA:
                showMFAScreen(callingActivity);
                break;
            case NEW_PASSWORD_REQUIRED:
                showChangePassword(callingActivity);
                break;
            case DONE:
                showAppScreen(callingActivity, UserpoolSignInProvider.class);
                break;
            default:
                Log.wtf(TAG, "Unhandled sign-in case.");
        }
    }

    public static void showAppScreen(final Activity callingActivity, final Class providerClass) {
        callingActivity.startActivity(new Intent(callingActivity, WelcomeActivity.class).putExtra("provider", providerClass));
    }

    public static void showChangePassword(final Activity callingActivity) {
        Log.e(TAG, "implement showChangePassword");
        callingActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(callingActivity, "implement showChangePassword", Toast.LENGTH_LONG).show();
                UserpoolSignInProvider up = auth.getSignInProvider(UserpoolSignInProvider.class);
                up.changePassword("1234Password!", new Callback<UserpoolSignInResult>() {
                    @Override
                    public void onResult(UserpoolSignInResult result) {
                        Log.e(TAG, "handle onResult changePassword: " + result);
                    }

                    @Override
                    public void onError(Exception e) {
                        Log.e(TAG, "handle onError changePassword", e);
                    }
                });
            }
        });
    }

    public static void showMFAScreen(final Activity callingActivity) {
        Log.e(TAG, "implement showMFAScreen");
        callingActivity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(callingActivity, "implement showMFAScreen", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void loginGoogle(View view) {
        GoogleSignInDetails details = GoogleSignInDetails.builder().activity(this).build();

        auth.signIn(details, new Callback<GoogleSignInResult>() {
            @Override
            public void onResult(final GoogleSignInResult result) {
                MainActivity.showAppScreen(MainActivity.this, GoogleSignInProvider.class);
            }

            @Override
            public void onError(Exception e) {
                Log.e(TAG, "Google login onError called.", e);
            }
        });
    }

    public void logout(View view) {
        auth.signOut();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (auth != null) {
            auth.onActivityResult(requestCode, resultCode, data);
        }
        Log.e(TAG, "request code: " + requestCode + "");
    }
}
