package com.amazonaws.amplify.demo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

import com.amazonaws.amplify.auth.async.Callback;
import com.amazonaws.amplify.auth.userpool.UserpoolSignInDetails;
import com.amazonaws.amplify.auth.userpool.UserpoolSignInProvider;
import com.amazonaws.amplify.auth.userpool.UserpoolSignInResult;

public class UserpoolSignInActivity extends AppCompatActivity {
    private static final String TAG = UserpoolSignInActivity.class.getSimpleName();

    EditText usernameField;
    EditText passwordField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userpool_sign_in);
        usernameField = (EditText) findViewById(R.id.username);
        passwordField = (EditText) findViewById(R.id.password);

        String username = "again";
        String password = "1234Password!";
        usernameField.setText(username);
        usernameField.setSelection(username.length());
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        passwordField.setText(password);
        passwordField.setSelection(password.length());

        passwordField.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
                signIn(textView);
                return true;
            }
        });
    }

    public void signIn(View view) {
        final String username = usernameField.getText().toString();
        final String password = passwordField.getText().toString();
        UserpoolSignInDetails details = new UserpoolSignInDetails(username, password);

        MainActivity.getAuth().signIn(details, new Callback<UserpoolSignInResult>() {
            @Override
            public void onResult(UserpoolSignInResult result) {
                MainActivity.handleUserpoolSignInResult(result, UserpoolSignInActivity.this);
            }

            @Override
            public void onError(Exception e) {
                Log.e(TAG, "Userpool sign-in failed.", e);
            }
        });
    }

    public void clear(View view) {
        usernameField.setText("");
        passwordField.setText("");
    }
}
