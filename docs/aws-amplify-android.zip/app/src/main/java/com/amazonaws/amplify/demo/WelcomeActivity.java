package com.amazonaws.amplify.demo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.amazonaws.amplify.auth.Auth;
import com.amazonaws.amplify.auth.SignInProvider;
import com.amazonaws.amplify.auth.async.Callback;
import com.amazonaws.amplify.auth.userpool.UserpoolSignInProvider;

public class WelcomeActivity extends AppCompatActivity {
    private static final String TAG = WelcomeActivity.class.getSimpleName();

    private TextView identityIdField;
    private TextView tokenField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        identityIdField = (TextView) findViewById(R.id.identityid);
        tokenField = (TextView) findViewById(R.id.token);

        Auth auth = MainActivity.getAuth();

        auth.getIdentityId(new Callback<String>() {
            @Override
            public void onResult(final String result) {
                WelcomeActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        identityIdField.setText(result);
                    }
                });
            }

            @Override
            public void onError(Exception e) {
                Log.e(TAG, "Failed to fetch identity id", e);
            }
        });

        Class providerClass = (Class<? extends SignInProvider>) getIntent().getSerializableExtra("provider");
        String token = auth.getToken(providerClass);
        tokenField.setText(token);
    }
}
