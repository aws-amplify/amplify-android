package com.amazonaws.amplify.auth;

/**
 * Provides more functionality than the basic {@link SignInProvider}.
 */
public interface AdvancedSignInProvider {

    /**
     * Initiates the sign up process.
     */
    void signUp();

    /**
     * Provides confirmations such as code sent by SMS, email, or token.
     */
    void confirmSignUp();

    /**
     * Initiates the forgot password process.
     */
    void forgotPassword();

    /**
     * Provides confirmations such as code sent by SMS, email, or token.
     */
    void confirmForgotPassword();

    /**
     * Change user password.
     */
    void changePassword();

    /**
     * Sets what MFA method user will use.
     */
    void setMFAType();

    /**
     * Provide MFA code to service.
     */
    void confirmMFA();

}
