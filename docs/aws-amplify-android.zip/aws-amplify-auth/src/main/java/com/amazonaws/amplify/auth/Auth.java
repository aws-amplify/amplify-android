package com.amazonaws.amplify.auth;

import android.content.Context;
import android.content.Intent;
import android.os.Looper;
import android.util.Log;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.amplify.auth.async.Callback;
import com.amazonaws.amplify.auth.federated.FederatedSignInDetails;
import com.amazonaws.amplify.auth.federated.FederatedSignInResult;
import com.amazonaws.amplify.auth.userpool.UserpoolSignInProvider;
import com.amazonaws.amplify.auth.userpool.UserpoolSignInProviderBuilder;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.CognitoCachingCredentialsProvider;
import com.amazonaws.auth.CognitoCredentialsProvider;
import com.amazonaws.mobile.config.AWSConfiguration;
import com.amazonaws.regions.Regions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Auth {

    private static final String TAG = Auth.class.getSimpleName();

    private AWSCredentialsProvider credentialsProvider;
    private AWSConfiguration awsConfiguration;
    private ClientConfiguration clientConfiguration;

    private Map<Class< ? extends SignInProvider>, SignInProvider> signInProviders =
            new HashMap<Class< ? extends SignInProvider>, SignInProvider>();

    private ExecutorService executorService =
            Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
    private boolean isSignedIn;
    private SignInProvider lastProvider;
    private SignInProvider inProgressProvider;

    /**
     * Construct the Auth object based on the input received from the
     * Auth.Builder object
     * @param builder the builder object
     */
    public Auth(Builder builder) {
        this.clientConfiguration = builder.clientConfiguration;
        this.awsConfiguration = builder.awsConfiguration;
        this.credentialsProvider = createCredentialsProvider(builder);

        for (final SignInProviderBuilder signInProviderBuilder : builder.signInProviderBuilders) {
            createSignInProvidersInternal(signInProviderBuilder);
        }
    }

    public static Builder builder() {
        return new Builder();
    }

    /**
     * Place this in the onActivityResult of the Activity that initiates authentication when required.
     * @param requestCode
     * @param resultCode
     * @param data
     */
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        ((OAuthSignInProvider) inProgressProvider).onActivityResult(requestCode, resultCode, data);
    }

    public static class Builder {
        private Context context;
        private AWSCredentialsProvider credentialsProvider;
        private AWSConfiguration awsConfiguration;
        private ClientConfiguration clientConfiguration;
        private List<SignInProviderBuilder> signInProviderBuilders;
        private String cognitoIdentityPoolId;
        private Regions cognitoIdentityRegion;
        private boolean enableCachingForCognitoCredentialsProvider;
        private String accessKey;
        private String secretAccessKey;

        Builder() {
            this.signInProviderBuilders = new ArrayList<SignInProviderBuilder>();
        }

        /**
         * Developer provides the context to be used to construct the
         * SignInProvider and CredentialsProvider
         * @param context the context
         * @return builder
         */
        public Builder context(final Context context) {
            this.context = context.getApplicationContext();
            return this;
        }

        /**
         * Developer provides the input required to construct the
         * SignInProvider through the SignInProviderBuilder.
         * @param signInProviderBuilder the builder object for SignInProvider
         * @return builder
         */
        public Builder provider(final SignInProviderBuilder signInProviderBuilder) {
            this.signInProviderBuilders.add(signInProviderBuilder);
            return this;
        }

        /**
         * Developer provides implementation of credential provider for use
         * @param accessKey the access key
         * @param secretAccessKey the secret access key
         * @return builder
         */
        public Builder staticCredentials(final String accessKey, final String secretAccessKey) {
            this.accessKey = accessKey;
            this.secretAccessKey = secretAccessKey;
            return this;
        }

        /**
         * Developer provides the Cognito Identity PoolID, region and the option to enable caching
         * of AWSCredentials and IdentityID in order to construct the CognitoCredentialsProvider
         * or CognitoCachingCredentialsProvider.
         * @param poolID the Cognito Identity Pool Id
         * @param region the Cognito Identity Region
         * @param enablingCaching if true create CognitoCachingCredentialsProvider,
         *                        else create CognitoCredentialsProvider.
         * @return builder
         */
        public Builder cognitoIdentityPool(final String poolID, final Regions region, final boolean enablingCaching) {
            this.cognitoIdentityPoolId = poolID;
            this.cognitoIdentityRegion = region;
            this.enableCachingForCognitoCredentialsProvider = enablingCaching;
            return this;
        }

        /**
         * Developer provides the AWSConfiguration object that represents the
         * awsconfiguration.json file.
         * @param awsConfiguration
         * @return builder
         */
        public Builder awsConfiguration(final AWSConfiguration awsConfiguration) {
            this.awsConfiguration = awsConfiguration;
            return this;
        }

        /**
         * Developer provides the ClientConfiguration object.
         * @param clientConfiguration
         * @return builder
         */
        public Builder clientConfiguration(final ClientConfiguration clientConfiguration) {
            this.clientConfiguration = clientConfiguration;
            return this;
        }

        /**
         * Build the Auth object based on the input passed through the Auth.Builder object
         * @return the built Auth object
         */
        public Auth build() {
            // TODO validate all input before constructing Auth object
            if (this.context == null) {
                throw new IllegalStateException("Context cannot be null.");
            }

            if (this.awsConfiguration == null &&
                (this.accessKey == null && this.secretAccessKey == null) &&
                this.cognitoIdentityPoolId == null) {
                throw new IllegalStateException("No valid configuration found. Please pass in exactly one of the following:" +
                        "AWSConfiguration or Static Credentials or CognitoIdentityPoolId");
            }

            if (this.awsConfiguration != null &&
                ((this.accessKey == null && this.secretAccessKey == null) ||
                 this.cognitoIdentityPoolId != null ||
                 !this.signInProviderBuilders.isEmpty())) {
                throw new IllegalStateException("Multiple configuration found. Please pass in exactly one of the following:" +
                        "AWSConfiguration or Static Credentials or CognitoIdentityPoolId");
            }

            return new Auth(this);
        }
    }

    public <P extends SignInProvider, C extends Callback<ResultT>, ResultT> void signIn(SignInDetails<P, C, ResultT> details, final C callback) {

        if (details instanceof FederatedSignInDetails) {
            federate(((FederatedSignInDetails) details).getSignInProviderKey(), ((FederatedSignInDetails) details).getSignInProviderToken());
            return; // Federated sign in launched
        }

        final SignInProvider signInProvider = getSignInProvider(details.getSignInProviderClass());

        if (signInProvider == null) {
            // Fail
            throw new IllegalArgumentException("Failed to find SignInProvider for the provided SignInDetails object.");
        }

        inProgressProvider = signInProvider;
        signInProvider.signIn(details, new Callback<ResultT>() {
            @Override
            public void onResult(final ResultT result) {
                Runnable work = new Runnable() {
                    @Override
                    public void run() {
                        Log.e(TAG, "Sign-in received");
                        if (!(signInProvider instanceof UserpoolSignInProvider)) {
                            lastProvider = signInProvider;
                            federate(signInProvider.getLoginKey(), signInProvider.getToken());
                            inProgressProvider = null;
                        }

                        callback.onResult(result);
                    }
                };

                if (Looper.myLooper() == Looper.getMainLooper()) {
                    new Thread(work).start();
                } else {
                    work.run();
                }
            }

            @Override
            public void onError(Exception e) {
                callback.onError(e);
            }
        });
        return; // Sign in with provider launched
    }

    private void federate(final String key, final String token) {
        CognitoCredentialsProvider cognitoCredentialsProvider;
        try {
            final Map<String, String> loginMap = new HashMap<String, String>();
            Log.e(TAG, "token " + token + " key " + key);
            loginMap.put(key, token);

            cognitoCredentialsProvider = (CognitoCredentialsProvider) credentialsProvider;
            cognitoCredentialsProvider.clear();
            cognitoCredentialsProvider.setLogins(loginMap);
            cognitoCredentialsProvider.refresh();
        } catch (final Exception exception) {
            throw new RuntimeException("Error in federating the token.", exception);
        }

        try {
            // Ensure identityId and credentials can be retrieved.
            final String identityId = cognitoCredentialsProvider.getIdentityId();
            final AWSCredentials awsCredentials = cognitoCredentialsProvider.getCredentials();
        } catch (final Exception exception) {
            throw new RuntimeException("Error in retrieving the Cognito Identity Id and the AWSCredentials", exception);
        }
    }

    /**
     *
     * @return
     */
    public boolean isSignedIn() {
        // TODO check for sign in
        return isSignedIn;
    }

    public void signOut() {
        isSignedIn = false;
        lastProvider.signOut();
        if (credentialsProvider instanceof CognitoCredentialsProvider) {
            ((CognitoCredentialsProvider) credentialsProvider).clear();
        }
    }

    // TODO check/ignore duplicate calls to getCredentials and getIdentityId

    /**
     * Retrieve the Cognito identity id. This method calls makes a network call
     * to Amazon Cognito Federated Identities in order to fetch the Identity Id.
     *
     * This method only applies to AWSCredentialsProvider of
     * type CognitoCredentialsProvider.
     *
     * @return identityId
     */
    public String getIdentityId() throws Exception {
        try {
            return ((CognitoCredentialsProvider) credentialsProvider).getIdentityId();
        } catch (final Exception exception) {
            throw new Exception("Error in retrieving the identity id", exception);
        }
    }

    /**
     * Retrieve the Cognito identity id. This method makes the network call
     * to Amazon Cognito Federated Identities in a background thread.
     *
     * This method only applies to AWSCredentialsProvider of
     * type CognitoCredentialsProvider.
     *
     * @param getIdentityCallback The callback object whose onResult will be called upon success
     *                            and onError will be called upon failure while retrieving the
     *                            identityId.
     */
    public void getIdentityId(final Callback<String> getIdentityCallback) {
        executorService.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    // TODO check for caching and call getCachedIdentityId instead
                    String identityId = ((CognitoCredentialsProvider) credentialsProvider).getIdentityId();
                    getIdentityCallback.onResult(identityId);
                } catch (final Exception exception) {
                    getIdentityCallback.onError(exception);
                }
            }
        });
    }

    /**
     * Returns the token associated with the SignInProvider used
     * @param tokenSource
     * @return
     */
    public String getToken(final Class<? extends SignInProvider> tokenSource) {
        return ((CognitoCredentialsProvider) credentialsProvider).getLogins().get(signInProviders.get(tokenSource).getLoginKey());
    }

    /**
     * Returns the token associated with the SignInProvider used
     * @param mappingValueForToken
     * @return
     */
    public String getToken(final String mappingValueForToken) {
        return ((CognitoCredentialsProvider) credentialsProvider).getLogins().get(mappingValueForToken);
    }

    public AWSCredentialsProvider getCredentialsProvider() {
        return credentialsProvider;
    }

    /**
     * Retrieve the AWSCredentials from the AWSCredentialsProvider.
     * This method makes a network call in order to fetch the credentials.
     *
     * @return awsCredentials that wraps the Access, Secret Access and Session key.
     */
    public AWSCredentials getAWSCredentials() throws Exception {
        try {
            return credentialsProvider.getCredentials();
        } catch (final Exception exception) {
            throw new Exception("Error in retrieving the AWSCredentials.", exception);
        }
    }

    /**
     * Retrieve the AWSCredentials from the AWSCredentialsProvider.
     * This method makes a network call from a background thread
     * in order to fetch the credentials.
     *
     * @param awsCredentialsAuthCallback The callback object whose onResult will be
     *                                   called with the valid AWSCredentials upon success
     *                                   and onError with exception upon failure.
     */
    public void getAWSCredentials(final Callback<AWSCredentials> awsCredentialsAuthCallback) {
        executorService.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    final AWSCredentials awsCredentials = getAWSCredentials();
                    awsCredentialsAuthCallback.onResult(awsCredentials);
                } catch (final Exception exception) {
                    awsCredentialsAuthCallback.onError(exception);
                }
            }
        });
    }

    /**
     * Gets the provider based on the class provided.
     * Usage
     * <code>
     *     GoogleSignInProvider provider = auth.getSignInProvider(GoogleSignInProvider.class);
     * </code>
     * @param providerClass
     * @return
     */
    public <T extends SignInProvider> T getSignInProvider(Class<? extends SignInProvider> providerClass) {
        return (T) this.signInProviders.get(providerClass);
    }

    /**
     * Create a SignInProvider object based on the builder object passed in.
     *
     * Usage:
     * <code>
     *     GoogleSignInProvider gsp = auth.createSignInProvider(new GoogleSignInProviderBuilder().activity(myActivity));
     * </code>
     * @param builder
     * @return the SignInProvider object
     */
    public <T extends SignInProvider> T createSignInProvider(SignInProviderBuilder builder) {
        return createSignInProvidersInternal(builder);
    }

    private Callback<SignInProvider> signInCallback = new Callback<SignInProvider>() {
        @Override
        public void onResult(SignInProvider result) {
            lastProvider = result;
            federate(result.getLoginKey(), result.getToken());
            inProgressProvider = null;
        }

        @Override
        public void onError(Exception e) {
            Log.w(TAG, "Internal error for sign-in", e);
        }
    };

    /**
     * Create the SignInProvider object based on the builder object passed in
     * and add it to the internal map of signInProviders.
     * @param builder
     */
    private <T extends SignInProvider> T createSignInProvidersInternal(SignInProviderBuilder builder) {
        if (builder instanceof UserpoolSignInProviderBuilder) {
            ((UserpoolSignInProviderBuilder) builder).callback(signInCallback);
        }

        SignInProvider signInProvider = builder.build();
        for (SignInProvider provider : signInProviders.values()) {
            if (provider.getLoginKey().equals(signInProvider.getLoginKey())) {
                throw new IllegalArgumentException("SignInProvider with the login key : "
                        + provider.getLoginKey() + " already exists.");
            }
        }

        if (signInProviders.get(signInProvider.getClass()) != null) {
            throw new IllegalArgumentException("SignInProvider already exists.");
        }

        signInProviders.put(signInProvider.getClass(), signInProvider);
        return (T) signInProvider;
    }

    /**
     * Construct the CredentialsProvider object based on the configuration
     * information available in the Auth.Builder
     *
     * @return awsCredentialsProvider
     */
    private AWSCredentialsProvider createCredentialsProvider(final Auth.Builder builder) {
        if (builder.cognitoIdentityPoolId != null && builder.cognitoIdentityRegion != null) {
            if (builder.enableCachingForCognitoCredentialsProvider) {
                return new CognitoCachingCredentialsProvider(builder.context, builder.cognitoIdentityPoolId, builder.cognitoIdentityRegion);
            } else {
                return new CognitoCredentialsProvider(builder.cognitoIdentityPoolId, builder.cognitoIdentityRegion);
            }
        } else if (builder.accessKey != null && builder.secretAccessKey != null) {
            return new AWSCredentialsProvider() {
                @Override
                public AWSCredentials getCredentials() {
                    return new BasicAWSCredentials(builder.accessKey, builder.secretAccessKey);
                }

                @Override
                public void refresh() {

                }
            };
        } else if (this.awsConfiguration != null) {
            if (builder.enableCachingForCognitoCredentialsProvider) {
                return new CognitoCachingCredentialsProvider(builder.context, builder.awsConfiguration);
            } else {
                return new CognitoCredentialsProvider(builder.awsConfiguration);
            }
        } else {
            throw new IllegalArgumentException("No valid configuration found to create credential provider.");
        }
    }
}
