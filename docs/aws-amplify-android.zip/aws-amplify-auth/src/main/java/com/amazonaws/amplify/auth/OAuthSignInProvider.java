package com.amazonaws.amplify.auth;

import android.content.Intent;

/**
 * Extends {@link SignInProvider} to include scopes used in OAuth protocol.
 */
public interface OAuthSignInProvider<D, R, T> extends SignInProvider<D, R> {

    /**
     * Get scope.
     * @return scopes that will be requested upon sign in
     */
    T[] getScopes();

    /**
     * Set the scopes requested upon sign in
     * @param scopes the scopes requested upon sign in
     */
    void setScopes(T... scopes);

    /**
     * Process the onActivityResult parameters from Activity to complete sign-in
     * @param requestCode
     * @param resultCode
     * @param data
     */
    void onActivityResult(int requestCode, int resultCode, Intent data);
}
