package com.amazonaws.amplify.auth;

/**
 * The interface that groups the objects passed into Auth signIn
 * @param <ProviderT> SignInProvider type that uses these details to sign in.
 * @param <CallbackT> The callback object used
 * @param <ResultT> The result object type produced from signing in.
 */
public interface SignInDetails<ProviderT extends SignInProvider, CallbackT, ResultT> {
    Class<ProviderT> getSignInProviderClass();
}
