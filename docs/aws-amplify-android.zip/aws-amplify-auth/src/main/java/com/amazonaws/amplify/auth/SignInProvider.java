package com.amazonaws.amplify.auth;

import com.amazonaws.amplify.auth.async.Callback;

/**
 * Interface defining standard methods for sign in.
 * TODO Methods should be vetted
 */
public interface SignInProvider<D, R> {

    /**
     * TODO Add this when other providers are ready
     */
//    R signIn(D details);

    /**
     *
     */
    void signIn(D details, Callback<R> callback);

    /**
     *
     */
    void signOut();

    /**
     *
     */
    void refresh();

    /**
     *
     */
    String getLoginKey();

    /**
     *
     */
    String getDisplayName();

    /**
     *
     */
    String getToken();

    /**
     *
     */
    String getRefreshToken();
}
