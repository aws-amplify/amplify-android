package com.amazonaws.amplify.auth;

public abstract class SignInProviderBuilder {
    /**
     * Builds the SignInProvider object based on the input passed through the builder.
     * @return SignInProvider object
     */
    protected abstract SignInProvider build();
}
