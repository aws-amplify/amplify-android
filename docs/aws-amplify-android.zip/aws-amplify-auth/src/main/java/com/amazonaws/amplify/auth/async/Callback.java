package com.amazonaws.amplify.auth.async;

/**
 * Callback async operations.
 * @param <R>
 */
public interface Callback<R> {
    void onResult(R result);

    void onError(Exception e);
}
