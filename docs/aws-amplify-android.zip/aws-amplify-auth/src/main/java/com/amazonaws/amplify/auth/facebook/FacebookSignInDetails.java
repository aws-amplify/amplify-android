package com.amazonaws.amplify.auth.facebook;

import android.app.Activity;
import android.content.Intent;

import com.amazonaws.amplify.auth.SignInDetails;
import com.amazonaws.amplify.auth.async.Callback;

public class FacebookSignInDetails implements SignInDetails<FacebookSignInProvider, Callback<FacebookSignInResult>, FacebookSignInResult> {

    private final Activity activity;
    private String[] scopes;

    public String[] getScopes() {
        return scopes;
    }

    public Activity getActivity() {
        return this.activity;
    }

    protected FacebookSignInDetails(FacebookSignInDetails.Builder builder) {
        this.activity = builder.activity;
        this.scopes = builder.scopes;
    }

    public static FacebookSignInDetails.Builder builder() {
        return new FacebookSignInDetails.Builder();
    }

    @Override
    public Class<FacebookSignInProvider> getSignInProviderClass() {
        return FacebookSignInProvider.class;
    }

    public static class Builder {
        private Activity activity;
        private String[] scopes;

        Builder() {
        }

        /**
         * @param activity Activity used to launch google sign-in
         *                 and receives {@link Activity#onActivityResult(int, int, Intent)} call.
         * @return builder
         */
        public FacebookSignInDetails.Builder activity(Activity activity) {
            this.activity = activity;
            return this;
        }

        /**
         * @param scopes Scopes requested during sign in.
         * @return builder
         */
        public FacebookSignInDetails.Builder scopes(String... scopes) {
            this.scopes = scopes;
            return this;
        }

        /**
         */
        public FacebookSignInDetails build() {
            return new FacebookSignInDetails(this);
        }
    }
}
