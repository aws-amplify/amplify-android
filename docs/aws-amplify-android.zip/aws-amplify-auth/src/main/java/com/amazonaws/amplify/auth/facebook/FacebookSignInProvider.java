package com.amazonaws.amplify.auth.facebook;

import android.content.Intent;
import android.util.Log;

import com.amazonaws.amplify.auth.OAuthSignInProvider;
import com.amazonaws.amplify.auth.async.Callback;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;

import java.util.List;

public class FacebookSignInProvider implements OAuthSignInProvider<FacebookSignInDetails, FacebookSignInResult, String> {

    private static final String TAG = FacebookSignInProvider.class.getSimpleName();
    private List<String> scopes;
    private CallbackManager callbackManager;

    FacebookSignInProvider(final FacebookSignInProviderBuilder builder) {
        if (!FacebookSdk.isInitialized()) {
            // TODO: Add InitializeCallback
            FacebookSdk.sdkInitialize(builder.getContext());
        }
        callbackManager = CallbackManager.Factory.create();
        LoginManager.getInstance().registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        // App code
                    }

                    @Override
                    public void onCancel() {
                        // App code
                    }

                    @Override
                    public void onError(FacebookException exception) {
                        // App code
                    }
                });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * Get scope.
     *
     * @return scopes that will be requested upon sign in
     */
    @Override
    public String[] getScopes() {
        return (String[]) scopes.toArray();
    }

    /**
     * Set the scopes requested upon sign in
     *
     * @param scopes the scopes requested upon sign in
     */
    @Override
    public void setScopes(String... scopes) {
        for (String scope : scopes) {
            this.scopes.add(scope);
        }
    }

    /**
     * SignIn with Facebook with the details and the callback with result.
     *
     * @param facebookSignInDetails
     * @param callback
     */
    @Override
    public void signIn(FacebookSignInDetails facebookSignInDetails, Callback<FacebookSignInResult> callback) {
        this.setScopes(facebookSignInDetails.getScopes());
        LoginManager.getInstance().logInWithReadPermissions(facebookSignInDetails.getActivity(), this.scopes);
    }

    /**
     *
     */
    @Override
    public void signOut() {
        LoginManager.getInstance().logOut();
    }

    /**
     *
     */
    @Override
    public String getLoginKey() {
        return "graph.facebook.com";
    }

    /**
     *
     */
    @Override
    public String getDisplayName() {
        return "Facebook";
    }

    /**
     *
     */
    @Override
    public String getToken() {
        final AccessToken accessToken = AccessToken.getCurrentAccessToken();
        if (accessToken != null && !accessToken.isExpired()) {
            Log.d(TAG, "Facebook Access Token is valid.");
            return accessToken.getToken();
        }

        Log.d(TAG, "Facebook Access Token is not present or expired.");
        return null;
    }

    /**
     *
     */
    @Override
    public void refresh() {

    }

    /**
     *
     */
    @Override
    public String getRefreshToken() {
       return null;
    }
}
