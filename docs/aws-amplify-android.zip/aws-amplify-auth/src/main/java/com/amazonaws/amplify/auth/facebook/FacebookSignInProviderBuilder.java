package com.amazonaws.amplify.auth.facebook;

import android.content.Context;

import com.amazonaws.amplify.auth.SignInProviderBuilder;

public class FacebookSignInProviderBuilder extends SignInProviderBuilder {

    private Context context;
    private String[] scopes;

    public Context getContext() {
        return context;
    }

    public String[] getScopes() {
        return scopes;
    }

    public FacebookSignInProviderBuilder context(final Context context) {
        this.context = context;
        return this;
    }

    public FacebookSignInProviderBuilder scopes(final String... scopes) {
        this.scopes = scopes;
        return this;
    }

    protected FacebookSignInProvider build() {
        FacebookSignInProvider facebookSignInProvider = new FacebookSignInProvider(this);
        facebookSignInProvider.setScopes(this.scopes);
        return facebookSignInProvider;
    }
}
