package com.amazonaws.amplify.auth.facebook;

public class FacebookSignInResult {

}
