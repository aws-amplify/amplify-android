package com.amazonaws.amplify.auth.federated;

import com.amazonaws.amplify.auth.SignInDetails;
import com.amazonaws.amplify.auth.SignInProvider;
import com.amazonaws.amplify.auth.async.Callback;

public class FederatedSignInDetails implements SignInDetails<SignInProvider, Callback<Boolean>, Boolean> {

    private String signInProviderKey;

    private String signInProviderToken;

    public String getSignInProviderToken() {
        return signInProviderToken;
    }

    public String getSignInProviderKey() {
        return signInProviderKey;
    }

    public FederatedSignInDetails(String signInProviderToken, String signInProviderKey) {
        this.signInProviderToken = signInProviderToken;
        this.signInProviderKey = signInProviderKey;
    }

    @Override
    public Class<SignInProvider> getSignInProviderClass() {
        return null;
    }
}
