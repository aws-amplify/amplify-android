package com.amazonaws.amplify.auth.federated;

import com.amazonaws.auth.AWSCredentials;

public class FederatedSignInResult {

    private AWSCredentials awsCredentials;

    private String identityId;

    public FederatedSignInResult(AWSCredentials awsCredentials, String identityId) {
        this.awsCredentials = awsCredentials;
        this.identityId = identityId;
    }

    public AWSCredentials getAwsCredentials() {
        return awsCredentials;
    }

    public String getIdentityId() {
        return identityId;
    }
}
