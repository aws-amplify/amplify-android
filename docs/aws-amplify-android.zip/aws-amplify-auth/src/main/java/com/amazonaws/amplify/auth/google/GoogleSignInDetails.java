package com.amazonaws.amplify.auth.google;

import android.app.Activity;
import android.content.Intent;

import com.amazonaws.amplify.auth.Auth;
import com.amazonaws.amplify.auth.SignInDetails;
import com.amazonaws.amplify.auth.async.Callback;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.Scope;

/**
 * Use builder to create class and pass into {@link Auth#signIn(SignInDetails, Callback)}
 */
public class GoogleSignInDetails implements SignInDetails<GoogleSignInProvider, Callback<GoogleSignInResult>, GoogleSignInResult> {

    private final Activity activity;
    private GoogleSignInOptions googleSignInOptions;

    protected GoogleSignInDetails(Builder builder) {
        this.activity = builder.activity;
        this.googleSignInOptions = builder.gsob.build();
    }

    public Activity getActivity() {
        return this.activity;
    }

    GoogleSignInOptions getGoogleSignInOptions() {
        return this.googleSignInOptions;
    }

    public static Builder builder() {
        return new Builder();
    }

    @Override
    public Class<GoogleSignInProvider> getSignInProviderClass() {
        return GoogleSignInProvider.class;
    }

    public static class Builder {
        private Activity activity;
        private GoogleSignInOptions.Builder gsob;

        Builder() {
            gsob = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN);
        }

        /**
         * @param activity Activity used to launch google sign-in
         *                 and receives {@link Activity#onActivityResult(int, int, Intent)} call.
         * @return builder
         */
        public Builder activity(Activity activity) {
            this.activity = activity;
            return this;
        }

        /**
         * Use Scopes for quick access to string constants.
         * @param scopes Scopes requested during sign in.
         * @return builder
         */
        public Builder scopes(String... scopes) {
            for (String scope : scopes) {
                this.gsob.requestScopes(new Scope(scope));
            }
            return this;
        }

        /**
         */
        public GoogleSignInDetails build() {
            return new GoogleSignInDetails(this);
        }
    }
}
