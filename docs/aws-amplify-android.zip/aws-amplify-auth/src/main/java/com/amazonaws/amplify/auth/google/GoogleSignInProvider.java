package com.amazonaws.amplify.auth.google;

import android.accounts.Account;
import android.content.Intent;
import android.os.Looper;
import android.util.Log;

import com.amazonaws.amplify.auth.OAuthSignInProvider;
import com.amazonaws.amplify.auth.async.Callback;
import com.google.android.gms.auth.GoogleAuthException;
import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.concurrent.Semaphore;

/**
 * Wrapper for the Google Sign In SDK.
 */
public class GoogleSignInProvider implements OAuthSignInProvider<GoogleSignInDetails, GoogleSignInResult, String> {
    private static final String TAG = GoogleSignInProvider.class.getSimpleName();

    /**
     * onActivityResult will have this value as the requestCode
     * if (requestCode == GoogleSignInProvider.RC_SIGN_IN) GoogleSignInProvider.onActivityResult(requestCode, resultCode, data);
     */
    public static final int RC_SIGN_IN = 9669;
    private final String clientID;

    private String[] scopeStrings;
    private GoogleSignInClient mGoogleSignInClient;
    private Semaphore signInLock;
    private GoogleSignInAccount account;
    private Callback callback;
    private GoogleSignInDetails details;
    private String token;

    public GoogleSignInProvider(GoogleSignInProviderBuilder builder) {
        signInLock = new Semaphore(1);
        clientID = builder.clientID();
    }

    @Override
    public String[] getScopes() {
        return scopeStrings;
    }

    @Override
    public void setScopes(String... scopes) {
        scopeStrings = scopes;
    }

    @Override
    public void signIn(GoogleSignInDetails details, Callback<GoogleSignInResult> callback) {
        if (!signInLock.tryAcquire()) {
            callback.onError(new IllegalStateException("Another sign in is in progress."));
        }
        this.details = details;
        this.callback = callback;

        GoogleSignInOptions gso = details.getGoogleSignInOptions();
        mGoogleSignInClient = GoogleSignIn.getClient(details.getActivity(), gso);
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        details.getActivity().startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == RC_SIGN_IN) {
            Log.e(TAG, "Received result code");
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount signInAccount = task.getResult(ApiException.class);
                final GoogleSignInResult result = new GoogleSignInResult();
                result.setAccount(account);
                final Account account = new Account(signInAccount.getEmail(), GoogleAuthUtil.GOOGLE_ACCOUNT_TYPE);
                final String scopes = "audience:server:client_id:" + clientID;
                Log.e("TAG", "Using scope " + scopes);

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            token = GoogleAuthUtil.getToken(details.getActivity(), account, scopes);

                            callback.onResult(result);
                        } catch (IOException e) {
                            callback.onError(e);
                        } catch (GoogleAuthException e) {
                            callback.onError(e);
                        } finally {
                            signInLock.release();
                        }
                    }
                }).start();
            } catch (Exception e) {
                signInLock.release();
                this.callback.onError(e);
            }
        }
    }

    @Override
    public void signOut() {
        mGoogleSignInClient.signOut();
    }

    @Override
    public void refresh() {

    }

    @Override
    public String getLoginKey() {
        return "accounts.google.com";
    }

    @Override
    public String getDisplayName() {
        return null;
    }

    @Override
    public String getToken() {
        return token;
    }

    @Override
    public String getRefreshToken() {
        return null;
    }
}
