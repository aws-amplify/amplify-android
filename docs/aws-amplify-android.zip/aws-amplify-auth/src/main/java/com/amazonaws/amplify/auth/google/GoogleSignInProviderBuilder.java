package com.amazonaws.amplify.auth.google;

import com.amazonaws.amplify.auth.SignInProviderBuilder;

public class GoogleSignInProviderBuilder extends SignInProviderBuilder {
    private String[] scopes;
    private String clientID;

    /**
     * Specify the web client id.
     * @param clientID web client id
     * @return builder
     */
    public GoogleSignInProviderBuilder clientID(final String clientID) {
        this.clientID = clientID;
        return this;
    }

    public GoogleSignInProviderBuilder scopes(final String... scopes) {
        this.scopes = scopes;
        return this;
    }

    protected GoogleSignInProvider build() {
        GoogleSignInProvider googleSignInProvider = new GoogleSignInProvider(this);
        googleSignInProvider.setScopes(this.scopes);
        return googleSignInProvider;
    }

    public String clientID() {
        return clientID;
    }
}
