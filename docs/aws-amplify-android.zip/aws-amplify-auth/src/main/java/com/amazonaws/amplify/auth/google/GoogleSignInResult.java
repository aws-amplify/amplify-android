package com.amazonaws.amplify.auth.google;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;

public class GoogleSignInResult {
    private GoogleSignInAccount account;

    public void setAccount(GoogleSignInAccount account) {
        this.account = account;
    }

    public GoogleSignInAccount getAccount() {
        return account;
    }
}
