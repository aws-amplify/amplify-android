package com.amazonaws.amplify.auth.google;

public interface GoogleSimpleCallback {
    void onCallback(String result, Exception e);
}
