package com.amazonaws.amplify.auth.userpool;

import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserAttributes;

import java.util.Map;

public class UserPoolSignUpDetails {
    String username;
    String password;
    CognitoUserAttributes userAttributes;
    Map<String, String> validationData;

    public UserPoolSignUpDetails(String username, String password, CognitoUserAttributes userAttributes, Map<String, String> validationData) {

        this.username = username;
        this.password = password;
        this.userAttributes = userAttributes;
        this.validationData = validationData;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public CognitoUserAttributes getUserAttributes() {
        return userAttributes;
    }

    public Map<String, String> getValidationData() {
        return validationData;
    }
}