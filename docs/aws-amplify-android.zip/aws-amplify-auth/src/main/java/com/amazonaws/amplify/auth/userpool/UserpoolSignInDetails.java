package com.amazonaws.amplify.auth.userpool;

import com.amazonaws.amplify.auth.SignInDetails;
import com.amazonaws.amplify.auth.async.Callback;

import java.util.Map;

public class UserpoolSignInDetails implements SignInDetails<UserpoolSignInProvider, Callback<UserpoolSignInResult>, UserpoolSignInResult> {

    private String username;
    private String password;
    private Map<String, String> validationData;

    public UserpoolSignInDetails(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public UserpoolSignInDetails(String username, String password, Map<String, String> validationData) {
        this.username = username;
        this.password = password;
        this.validationData = validationData;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public Map<String, String> getValidationData() {
        return validationData;
    }

    @Override
    public Class<UserpoolSignInProvider> getSignInProviderClass() {
        return UserpoolSignInProvider.class;
    }
}
