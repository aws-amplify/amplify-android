package com.amazonaws.amplify.auth.userpool;


import android.util.Log;

import com.amazonaws.amplify.auth.SignInProvider;
import com.amazonaws.amplify.auth.async.Callback;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoDevice;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUser;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserCodeDeliveryDetails;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserPool;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.CognitoUserSession;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.AuthenticationContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.AuthenticationDetails;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.ChallengeContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.MultiFactorAuthenticationContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.continuations.NewPasswordContinuation;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.AuthenticationHandler;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.GenericHandler;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.handlers.SignUpHandler;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.tokens.CognitoAccessToken;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.tokens.CognitoIdToken;
import com.amazonaws.mobileconnectors.cognitoidentityprovider.tokens.CognitoRefreshToken;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicReference;

public class UserpoolSignInProvider implements SignInProvider<UserpoolSignInDetails, UserpoolSignInResult> {
    private static final String TAG = UserpoolSignInProvider.class.getSimpleName();

    private final CognitoUserPool userpool;
    private final String loginKey;

    private MultiFactorAuthenticationContinuation mfaContinuation;
    private ChallengeContinuation challengeContinuation;

    private CognitoAccessToken mCognitoAccessToken;
    private CognitoRefreshToken mCognitoRefreshToken;
    private CognitoIdToken mCognitoIdToken;

    // Sign-in continuation callbacks give by customer
    private Callback<UserpoolSignInResult> signInCallback;
    private Callback<SignInProvider> signInListener;

    public enum SignInState {
        /**
         * Next challenge is to supply an SMS_MFA_CODE, delivered via SMS.
         */
        SMS_MFA("SMS_MFA"),

        /**
         * Next challenge is to supply PASSWORD_CLAIM_SIGNATURE, PASSWORD_CLAIM_SECRET_BLOCK, and TIMESTAMP after the client-side SRP calculations.
         */
        PASSWORD_VERIFIER("PASSWORD_VERIFIER"),

        /**
         * This is returned if your custom authentication flow determines that the user should pass another challenge before tokens are issued.
         */
        CUSTOM_CHALLENGE("CUSTOM_CHALLENGE"),

        /**
         * If device tracking was enabled on your user pool and the previous challenges were passed, this challenge is returned so that Amazon Cognito can start tracking this device.
         */
        DEVICE_SRP_AUTH("DEVICE_SRP_AUTH"),

        /**
         * Similar to PASSWORD_VERIFIER, but for devices only.
         */
        DEVICE_PASSWORD_VERIFIER("DEVICE_PASSWORD_VERIFIER"),

        /**
         * This is returned if you need to authenticate with USERNAME and PASSWORD directly. An app client must be enabled to use this flow.
         */
        ADMIN_NO_SRP_AUTH("ADMIN_NO_SRP_AUTH"),

        /**
         * For users which are required to change their passwords after successful first login. This challenge should be passed with NEW_PASSWORD and any other required attributes.
         */
        NEW_PASSWORD_REQUIRED("NEW_PASSWORD_REQUIRED"),

        /**
         * The flow is completed and no further steps are possible.
         */
        DONE("This means the flow is complete.");

        private final String serviceText;

        SignInState(final String serviceText) {
            this.serviceText = serviceText;
        }

        public boolean equals(final String serviceText) {
            return this.serviceText.equals(serviceText);
        }
    }

    protected UserpoolSignInProvider(UserpoolSignInProviderBuilder builder) {
        userpool = new CognitoUserPool(builder.getContext(), builder.getPoolId(), builder.getClientId(), builder.getClientSecret(), builder.getRegion());
        this.signInListener = builder.getSignInCallback();
        loginKey = String.format("cognito-idp.%s.amazonaws.com/%s", builder.getRegion().getName(), builder.getPoolId());
    }

    public UserpoolSignInResult signIn(final UserpoolSignInDetails details) {
        final Semaphore lock = new Semaphore(0);
        try {
            final AtomicReference<UserpoolSignInResult> resultReference = new AtomicReference<>();
            final AtomicReference<Exception> errorReference = new AtomicReference<>();
            signIn(details, new Callback<UserpoolSignInResult>() {
                @Override
                public void onResult(UserpoolSignInResult result) {
                    resultReference.set(result);
                    lock.release();
                }

                @Override
                public void onError(Exception e) {
                    errorReference.set(e);
                    lock.release();
                }
            });
            lock.acquire();
            if (errorReference.get() != null)
                throw new RuntimeException("Failed to signIn", errorReference.get());
            return resultReference.get();
        } catch (InterruptedException e) {
            throw new RuntimeException("Could not run signIn synchronously", e);
        }
    }

    @Override
    public void signIn(final UserpoolSignInDetails details, final Callback<UserpoolSignInResult> callback) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                signInInternal(details, callback);
            }
        }).start();
    }

    private void signInInternal(final UserpoolSignInDetails details, final Callback<UserpoolSignInResult> callback) {
        this.signInCallback = callback;

        userpool.getUser(details.getUsername()).getSession(new AuthenticationHandler() {

            @Override
            public void onSuccess(CognitoUserSession userSession, CognitoDevice newDevice) {
                try {
                    mCognitoAccessToken = userSession.getAccessToken();
                    mCognitoRefreshToken = userSession.getRefreshToken();
                    mCognitoIdToken = userSession.getIdToken();
                    Log.e(TAG, "Userpool signed-in id token:" + mCognitoIdToken.getJWTToken());
                    UserpoolSignInProvider.this.signInCallback.onResult(new UserpoolSignInResult(userSession.getAccessToken().getJWTToken()));
                    UserpoolSignInProvider.this.signInListener.onResult(UserpoolSignInProvider.this);
                } catch (Exception e) {
                    UserpoolSignInProvider.this.signInCallback.onError(e);
                }
            }

            @Override
            public void getAuthenticationDetails(AuthenticationContinuation authenticationContinuation, String userId) {
                authenticationContinuation.setAuthenticationDetails(new AuthenticationDetails(details.getUsername(), details.getPassword(), details.getValidationData()));
                Log.d(TAG, "Sending password.");
                authenticationContinuation.continueTask();
                // TODO Is following method call option necessary?
//                authenticationContinuation.setAuthenticationDetails(new AuthenticationDetails(details.getUsername(), details.getAuthenticationParameters(), details.getValidationData()));
            }

            @Override
            public void getMFACode(MultiFactorAuthenticationContinuation continuation) {
                UserpoolSignInProvider.this.mfaContinuation = continuation;
                UserpoolSignInProvider.this.signInCallback.onResult(new UserpoolSignInResult(SignInState.SMS_MFA));
            }

            @Override
            public void authenticationChallenge(ChallengeContinuation continuation) {
                try {
                    SignInState signInState = SignInState.valueOf(continuation.getChallengeName());
                    UserpoolSignInProvider.this.challengeContinuation = continuation;

                    UserpoolSignInProvider.this.signInCallback.onResult(new UserpoolSignInResult(signInState));
                } catch (IllegalArgumentException e) {
                    UserpoolSignInProvider.this.signInCallback.onError(e);
                }
            }

            @Override
            public void onFailure(Exception exception) {
                UserpoolSignInProvider.this.signInCallback.onError(exception);
            }
        });
    }

    @Override
    public void signOut() {
        userpool.getCurrentUser().signOut();
    }

    @Override
    public void refresh() {
        // TODO refresh token
    }

    @Override
    public String getLoginKey() {
        return loginKey;
    }

    @Override
    public String getDisplayName() {
        return null;
    }

    @Override
    public String getToken() {
        return mCognitoIdToken.getJWTToken();
    }

    @Override
    public String getRefreshToken() {
        return mCognitoRefreshToken.getToken();
    }

    public void signUp(final UserPoolSignUpDetails details) {
        userpool.signUp(details.getUsername(), details.getPassword(), details.getUserAttributes(), details.getValidationData(), new SignUpHandler() {
            @Override
            public void onSuccess(CognitoUser user, boolean signUpConfirmationState, CognitoUserCodeDeliveryDetails cognitoUserCodeDeliveryDetails) {
                user.confirmSignUp("confCode", true, new GenericHandler() {
                    @Override
                    public void onSuccess() {

                    }

                    @Override
                    public void onFailure(Exception exception) {

                    }
                });
            }

            @Override
            public void onFailure(Exception exception) {

            }
        });
    }

    public void confirmSignUp() {

    }

    public void forgotPassword(final String username) {
        // TODO check other ways to initiate forget password

    }

    public void confirmForgotPassword() {

    }

    /**
     * Call this method after receiving UserpoolSignInResult with state NEW_PASSWORD_REQUIRED
     *
     * @param newPassword
     * @param callback
     */
    public void changePassword(final String newPassword, final Callback<UserpoolSignInResult> callback) {
        new Thread((new Runnable() {
            @Override
            public void run() {
                if (challengeContinuation != null && SignInState.NEW_PASSWORD_REQUIRED.equals(challengeContinuation.getChallengeName())) {
                    NewPasswordContinuation newPasswordContinuation = (NewPasswordContinuation) challengeContinuation;
                    newPasswordContinuation.setPassword(newPassword);
                    UserpoolSignInProvider.this.signInCallback = callback;
                    newPasswordContinuation.continueTask();
                    return;
                } else {
                    callback.onError(new IllegalStateException("Cannot call changePassword(String, Callback) without initiating sign-in or receiving state CHANGE_PASSWORD"));
                }
            }
        })).start();
    }

    /**
     * Used to change the user password. This is not used for sign-in challenges.
     *
     * @param oldPassword
     * @param newPassword
     * @param callback
     */
    public void changePassword(final String oldPassword, final String newPassword, final Callback<Boolean> callback) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                userpool.getCurrentUser().changePasswordInBackground(oldPassword, newPassword, new GenericHandler() {
                    @Override
                    public void onSuccess() {
                        callback.onResult(true);
                    }

                    @Override
                    public void onFailure(Exception exception) {
                        callback.onError(exception);
                    }
                });
            }
        }).start();
    }


    /**
     * Used to change the user password. This is not used for sign-in challenges.
     *
     * @param oldPassword
     * @param newPassword
     */
    public boolean changePassword(final String oldPassword, final String newPassword) throws InterruptedException {
        final Semaphore lock = new Semaphore(0);
        final AtomicReference<Boolean> successRef = new AtomicReference<>();
        final AtomicReference<Exception> failureRef = new AtomicReference<>();
        userpool.getCurrentUser().changePassword(oldPassword, newPassword, new GenericHandler() {
            @Override
            public void onSuccess() {
                successRef.set(true);
                lock.release();
            }

            @Override
            public void onFailure(Exception exception) {
                failureRef.set(exception);
                lock.release();
            }
        });
        lock.acquire();
        if (failureRef.get() != null)
            throw new RuntimeException("Change password failed.", failureRef.get());
        return true;
    }

    public void setMFAType() {

    }

    /**
     * Call this method when signaled to by the signIn, signUp, or forgotPassword callbacks.
     *
     * @param mfaCode the code received by user via sms, email, etc based on settings
     */
    public void confirmMFA(final String mfaCode, final Callback<UserpoolSignInResult> callback) {
        if (challengeContinuation == null
                || !SignInState.SMS_MFA.equals(challengeContinuation.getChallengeName())) {
            callback.onError(new IllegalStateException("Cannot call confirmMFA(String, Callback) without initiating sign-in or receiving state SMS_MFA"));
            return;
        }

        this.mfaContinuation.setMfaCode(mfaCode);
        this.signInCallback = callback;

        new Thread((new Runnable() {
            @Override
            public void run() {
                UserpoolSignInProvider.this.mfaContinuation.continueTask();
            }
        })).start();
    }

    public void confirmChallenge() {

    }
}
