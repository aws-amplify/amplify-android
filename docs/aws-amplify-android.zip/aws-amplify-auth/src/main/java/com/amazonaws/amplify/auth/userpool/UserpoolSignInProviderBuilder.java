package com.amazonaws.amplify.auth.userpool;

import android.content.Context;

import com.amazonaws.amplify.auth.SignInProvider;
import com.amazonaws.amplify.auth.SignInProviderBuilder;
import com.amazonaws.amplify.auth.async.Callback;
import com.amazonaws.regions.Regions;

public class UserpoolSignInProviderBuilder extends SignInProviderBuilder {

    private Callback<SignInProvider> signInCallback;

    public UserpoolSignInProviderBuilder(Context context, Regions mRegion, String mPoolId, String mClientId, String mClientSecret) {
        this.context = context.getApplicationContext();
        this.mRegion = mRegion;
        this.mPoolId = mPoolId;
        this.mClientId = mClientId;
        this.mClientSecret = mClientSecret;
    }

    public UserpoolSignInProviderBuilder callback(final Callback<SignInProvider> signInCallback) {
        this.signInCallback = signInCallback;
        return this;
    }

    private Context context;
    private Regions mRegion;
    private String mPoolId;
    private String mClientId;
    private String mClientSecret;

    @Override
    protected UserpoolSignInProvider build() {
        return new UserpoolSignInProvider(this);
    }

    public Regions getRegion() {
        return mRegion;
    }

    public String getPoolId() {
        return mPoolId;
    }

    public String getClientId() {
        return mClientId;
    }

    public String getClientSecret() {
        return mClientSecret;
    }

    public Context getContext() {
        return context;
    }

    public Callback<SignInProvider> getSignInCallback() {
        return signInCallback;
    }
}
