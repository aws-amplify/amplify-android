package com.amazonaws.amplify.auth.userpool;

import static com.amazonaws.amplify.auth.userpool.UserpoolSignInProvider.SignInState;

public class UserpoolSignInResult {

    private UserpoolSignInResult(String jwtTokenString, UserpoolSignInProvider.SignInState signInState) {
        this.jwtTokenString = jwtTokenString;
        this.signInState = signInState;
    }

    // TODO determine correct set of returns here.
    private final String jwtTokenString;
    private final SignInState signInState;

    public UserpoolSignInResult(String jwtTokenString) {
        this(jwtTokenString, SignInState.DONE);
    }

    public UserpoolSignInResult(UserpoolSignInProvider.SignInState signInState) {
        this(null, signInState);
    }

    public UserpoolSignInProvider.SignInState getSignInState() {
        return signInState;
    }

    public String getJwtTokenString() {
        return jwtTokenString;
    }
}
