package com.amazonaws.amplify.auth;

import android.content.Context;

import com.amazonaws.regions.Regions;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.shadows.ShadowApplication;

import static junit.framework.Assert.assertNotNull;

@RunWith(RobolectricTestRunner.class)
public class AuthTest {
    @Before
    public void setup() {
        // TODO setup
    }

    @Test
    public void testBuilder() {
        final Context shadowContext = ShadowApplication.getInstance().getApplicationContext();
        Auth auth = Auth.builder()
                .context(shadowContext)
                .cognitoIdentityPool("poolId", Regions.DEFAULT_REGION, false)
                .build();
        assertNotNull(auth);
    }
}
