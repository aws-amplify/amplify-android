package com.amazonaws.amplify.auth.userpool;

import android.content.Context;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.shadows.ShadowApplication;

import static junit.framework.Assert.assertEquals;
import static junit.framework.Assert.assertNotNull;

@RunWith(RobolectricTestRunner.class)
public class UserPoolSignInProviderTest {
    @Before
    public void setup() {
        // TODO setup
    }

    @Test
    public void testEnum() {
        final Context shadowContext = ShadowApplication.getInstance().getApplicationContext();
        assertEquals(UserpoolSignInProvider.SignInState.SMS_MFA, UserpoolSignInProvider.SignInState.valueOf("SMS_MFA"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testEnumNoValue() {
        // No enum constant com.amazonaws.amplify.auth.userpool.UserpoolSignInProvider.SignInState.NO
        UserpoolSignInProvider.SignInState.valueOf("NO");
    }

    @Test
    public void testEnumNullValue() {
        UserpoolSignInProvider.SignInState nullValue = null;
        assertEquals(null, nullValue);
    }
}
