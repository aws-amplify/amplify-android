{% include header.html %}
# AWS Amplify Auth

## Setup

Add gradle dependencies to begin using the library.
    
```groovy
// Required as a base for Auth
implementation 'com.amazonaws:aws-amplify-auth:{{ site.sdk_version }}'
```

## Authentication using static credentials

Static credentials authenticate your API calls to AWS. This is an easy way to get started and experiment with your app without needing to have more advanced security. However, these credentials are hard to use with production apps because it is difficult to swap static credentials, often requiring forced app updates 😬.

Read [Access Key Best Practices](https://docs.aws.amazon.com/general/latest/gr/aws-access-keys-best-practices.html) for more information.

1. Create the `Auth` client.

    {% include tabs.html %}

    {% include tab_content_start.html lang="kt" %}

    ```kotlin
    val auth = Auth.builder()
                .staticCredentials("accessKey", "secretKey")
                .build()
    auth.awsCredentials
    ```

    {% include tab_content_end.html %}

    {% include tab_content_start.html lang="java" %}

    ```java
    Auth auth = Auth.builder()
                .staticCredentials("accessKey", "secretKey")
                .build();
    auth.getAWSCredentials();
    ```

    {% include tab_content_end.html %}

## Authentication using Cognito Identity

### - Unathenticated (or anonymous) users

Unauthenticated users (or anonmyous users) are users who have not yet signed in to the app. _For example, the user has opened your ecommerce app and is browsing through the catalog. The user has not signed into the app yet._ The app in this state can still make API calls to AWS by using the unauthenticated users feature of the Cognito Identity service. 

1. Create the `Auth` client.

    {% include tabs.html %}

    {% include tab_content_start.html lang="kt" %}

    ```kotlin
    val auth = Auth.builder()
                .context(context)
                .cognitoIdentityPool(getApplicationContext(), "us-west-2:abcd1234-abcd-1234-abcd-1234abcd1234", Regions.US_WEST_2)
                .build()
    ```

    {% include tab_content_end.html %}

    {% include tab_content_start.html lang="java" %}

    ```java
    Auth auth = Auth.builder()
                .cognitoIdentityPool(getApplicationContext(), "abcd1234-abcd-1234-abcd-1234abcd1234", Regions.US_WEST_2)
                .build();
    ```

    {% include tab_content_end.html %}

    The client can also be created with `AWSConfiguration` which reads configuration from `aws-configuration.json`.

    {% include tabs.html %}

    {% include tab_content_start.html lang="kt" %}

    ```kotlin
    val auth = Auth(AWSConfiguration(context))
    ```

    {% include tab_content_end.html %}

    {% include tab_content_start.html lang="java" %}

    ```java
    Auth auth = new Auth(new AWSConfiguration(context));
    ```

    {% include tab_content_end.html %}

### - Authenticated Users

Authenticated users are users who have signed in using a custom login mechanism or a social login such as facebook, google etc., and the information about the Identity of the user, usually a JSON Web Token (JWT) has been shared with the Cognito Identity service.

Once the JWT has been shared with Cognito Identity, it will then provide an identity id and AWSCredentials associated with the user that can be used to make API calls to AWS.

For example, the user signs into the app using a Cognito Userpool and the Userpool token is shared with Cognito Idenity, and Cognito Identity returns the identity id and AWS credentials.

#### Implementing sign in with User Pools

1. Add gradle depenencies if you authenticate Facebook, Google, or Userpool users.

    ```groovy
    // Adds Facebook sign-in capabilities
    implementation 'com.amazonaws:aws-amplify-auth-facebook:{{ site.sdk_version }}'

    // Adds Google sign-in capabilities
    implementation 'com.amazonaws:aws-amplify-auth-google:{{ site.sdk_version }}'

    // Adds Userpool sign-in capabilities
    implementation 'com.amazonaws:aws-amplify-auth-userpool:{{ site.sdk_version }}'
    ```

2. Create the `Auth` client. This step is the same as the previous unauthenticated section, however adds providers to be able to authenticate the user. This example is for a Userpool user.

    {% include tabs.html %}

    {% include tab_content_start.html lang="kt" %}

    ```kotlin
    val auth = Auth.builder()
                .cognitoIdentityPool(context, "us-west-2:abcd1234-abcd-1234-abcd-1234abcd1234", Regions.US_WEST_2)
                .provider(UserpoolSignInProviderBuilder(context, Regions.US_WEST_2, "userpoolId", "userpoolClientId", "userpoolClientSecret"))
                .build()
    ```

    {% include tab_content_end.html %}

    {% include tab_content_start.html lang="java" %}

    ```java
    Auth auth = Auth.builder()
                .cognitoIdentityPool(context, "abcd1234-abcd-1234-abcd-1234abcd1234", Regions.US_WEST_2)
                .provider(UserpoolSignInProviderBuilder(context, Regions.US_WEST_2, "userpoolId", "userpoolClientId", "userpoolClientSecret"))
                .build();
    ```
    
    {% include tab_content_end.html %}

3. Call `signIn`. This example is for a Userpool user.

    {% include tabs.html %}

    {% include tab_content_start.html lang="kt" %}

    ```kotlin
    val details = UserpoolSignInDetails(username: "bimin", "1234Password!")
    auth.signIn(details, object: Callback<UserpoolSignInResult>() {
        override fun onResult(result: UserpoolSignInResult) {
            when (result.state) {
                SignInState.SMS_MFA -> // Request MFA code from user
                SignInState.NEW_PASSWORD -> // Request new password from user
                SignInState.DONE -> // Handle completed sign-in
            }
        }

        override fun onError(error: Exception) {
            // Handle error
        }
    })
    ```

    {% include tab_content_end.html %}

    {% include tab_content_start.html lang="java" %}

    ```java
    UserpoolSignInDetails details = new UserpoolSignInDetails("bimin", "1234Password!");
    auth.signIn(details, new Callback<UserpoolSignInResult>() {
        @Override
        void onResult(final UserpoolSignInResult result) {
            switch (result.getState()) {
                case: SignInState.SMS_MFA: // Request MFA code from user
                case: SignInState.NEW_PASSWORD: // Request new password from user
                case: SignInState.DONE: // Handle completed sign-in
            }
        }

        @Override
        void onError(final Execption e) {
            // Handle error
        }
    });
    ```

    {% include tab_content_end.html %}

### - Identity Id

The identity id is associated with the user and the identity provider they used.
This id can be used to store and identify user resources such as an S3 folder with the id as the name and contents belonging to that user `user-abcd-123/attachment.jpg`.

{% include tabs.html %}

{% include tab_content_start.html lang="kt" %}

```kotlin
auth.identityId()
```

{% include tab_content_end.html %}

{% include tab_content_start.html lang="java" %}

```java
auth.getIdentityId();
```

{% include tab_content_end.html %}

Side notes: If `person A` signs in with Userpool and gets identity id `abcd-123`.
However, next time `person A` signs in with Google will get identity id `efgh-456` **unless the identity is merged**.

## Cognito User Pool

### Implementing sign-up with User Pools

{% include tabs.html %}

{% include tab_content_start.html lang="kt" %}

```kotlin
val userpool = auth.getProvider(UserpoolSignInProvider.javaClass)
val details = UserpoolSignUpDetails(username: "bimin", password: "1234Password!")
userpool.signUp(details, object: Callback<UserpoolSignUpResult>() {
    override fun onResult(result: UserpoolSignUpResult) {
        when (result.state) {
            SignUpState.SMS_MFA -> // Request MFA code from user
            SignUpState.DONE -> // Handle completed sign-in
        }
    }

    override fun onError(error: Exception) {
        // Handle error
    }
})
```

{% include tab_content_end.html %}

{% include tab_content_start.html lang="java" %}

```java
UserpoolSignInProvider userpool = auth.getProvider(UserpoolSignInProvider.class);
UserpoolSignUpDetails details = UserpoolSignUpDetails("bimin", "1234Password!");
userpool.signUp(details, new Callback<UserpoolSignUpResult>() {
    @Override
    public void onResult(UserpoolSignUpResult result) {
        switch (result.getState()) {
            case: SignUpState.SMS_MFA: // Request MFA code from user
            case: SignUpState.DONE: // Handle completed sign-in
        }
    }

    @Override
    void onError(final Execption e) {
        // Handle error
    }
})
```

{% include tab_content_end.html %}

## Authentication using Secure Token Service (STS)

The Secure Token Service (STS). Coming soon.

## API Reference

[Show me the APIs](/reference)

{% include footer.html %}
